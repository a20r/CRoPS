To run the program:
	From the "Flock Research" directory:
		python code/test_sim.py maps/{scene1.map, scene2.map, scene3.map}
		# Values in the {} means "one of the values"

Prerequistes:
	PyGame