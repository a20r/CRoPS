var annotated =
[
    [ "boid", "namespaceboid.html", "namespaceboid" ],
    [ "boidsimulation", "namespaceboidsimulation.html", "namespaceboidsimulation" ],
    [ "configuration", "namespaceconfiguration.html", "namespaceconfiguration" ],
    [ "dijkstra", "namespacedijkstra.html", null ],
    [ "gatherstats", "namespacegatherstats.html", null ],
    [ "goal", "namespacegoal.html", "namespacegoal" ],
    [ "mapparser", "namespacemapparser.html", null ],
    [ "obstacle", "namespaceobstacle.html", "namespaceobstacle" ],
    [ "priodict", "namespacepriodict.html", "namespacepriodict" ],
    [ "prm", "namespaceprm.html", "namespaceprm" ],
    [ "test_sim", "namespacetest__sim.html", null ],
    [ "dict", "classdict.html", null ]
];