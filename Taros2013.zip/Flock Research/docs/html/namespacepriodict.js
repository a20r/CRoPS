var namespacepriodict =
[
    [ "priorityDictionary", "classpriodict_1_1priorityDictionary.html", "classpriodict_1_1priorityDictionary" ]
];