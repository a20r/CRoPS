var classconfiguration_1_1Configuration =
[
    [ "boidSpeed", "classconfiguration_1_1Configuration.html#a5062047bc933b81cbbaa841e20cb2a67", null ],
    [ "colorList", "classconfiguration_1_1Configuration.html#a2140643801852e373bfddf9945cf26f8", null ],
    [ "dim", "classconfiguration_1_1Configuration.html#af63a65a65716f36cb11afd4d0e7f318f", null ],
    [ "goalRadius", "classconfiguration_1_1Configuration.html#a1a5fee18f20950a467d1b94d4d276c78", null ],
    [ "numNeighbours", "classconfiguration_1_1Configuration.html#a7eef6f8f2eb6d4a8fa4a45ddf9f6e1ba", null ],
    [ "numSamplePoints", "classconfiguration_1_1Configuration.html#a35685f1f81ce810f4a429654c6b27334", null ],
    [ "screen", "classconfiguration_1_1Configuration.html#a04b8c98906296ee65625d1472e037a75", null ]
];