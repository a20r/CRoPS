var searchData=
[
  ['priodict_2epy',['priodict.py',['../priodict_8py.html',1,'']]],
  ['prm_2epy',['prm.py',['../prm_8py.html',1,'']]]
];
