var searchData=
[
  ['update',['update',['../classboid_1_1Boid.html#a8a354e4b7d58ced69771f3bb5f52d257',1,'boid::Boid']]],
  ['updatepositionbuffer',['updatePositionBuffer',['../classboid_1_1Boid.html#a0eb922b53c2f4e30dc0d042d1649fd2c',1,'boid::Boid']]]
];
