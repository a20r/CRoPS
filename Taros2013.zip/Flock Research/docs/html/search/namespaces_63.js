var searchData=
[
  ['configuration',['configuration',['../namespaceconfiguration.html',1,'']]]
];
