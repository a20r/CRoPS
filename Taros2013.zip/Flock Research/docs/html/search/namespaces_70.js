var searchData=
[
  ['priodict',['priodict',['../namespacepriodict.html',1,'']]],
  ['prm',['prm',['../namespaceprm.html',1,'']]]
];
