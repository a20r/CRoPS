var searchData=
[
  ['ysize',['ySize',['../classboid_1_1Boid.html#a09f8fe6b2deb64fd65cfd64fc01470b9',1,'boid.Boid.ySize()'],['../classprm_1_1PRMGenerator.html#aaa5cf5ecddd099bf8c294cad0b33be92',1,'prm.PRMGenerator.ySize()']]]
];
