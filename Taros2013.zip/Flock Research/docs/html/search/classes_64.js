var searchData=
[
  ['dict',['dict',['../classdict.html',1,'']]]
];
