var searchData=
[
  ['gatherstats',['gatherstats',['../namespacegatherstats.html',1,'']]],
  ['goal',['goal',['../namespacegoal.html',1,'']]]
];
