var hierarchy =
[
    [ "boid.Boid", "classboid_1_1Boid.html", null ],
    [ "goal.CircleGoal", "classgoal_1_1CircleGoal.html", null ],
    [ "configuration.Configuration", "classconfiguration_1_1Configuration.html", [
      [ "configuration.PolyFileConfiguration", "classconfiguration_1_1PolyFileConfiguration.html", null ]
    ] ],
    [ "dict", "classdict.html", [
      [ "priodict.priorityDictionary", "classpriodict_1_1priorityDictionary.html", null ]
    ] ],
    [ "boidsimulation.FlockSim", "classboidsimulation_1_1FlockSim.html", null ],
    [ "obstacle.PolyObstacle", "classobstacle_1_1PolyObstacle.html", null ],
    [ "prm.PRMGenerator", "classprm_1_1PRMGenerator.html", null ]
];