var namespacegoal =
[
    [ "CircleGoal", "classgoal_1_1CircleGoal.html", "classgoal_1_1CircleGoal" ]
];