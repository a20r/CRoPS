var namespaceconfiguration =
[
    [ "Configuration", "classconfiguration_1_1Configuration.html", "classconfiguration_1_1Configuration" ],
    [ "PolyFileConfiguration", "classconfiguration_1_1PolyFileConfiguration.html", "classconfiguration_1_1PolyFileConfiguration" ]
];