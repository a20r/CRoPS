var classgoal_1_1CircleGoal =
[
    [ "__init__", "classgoal_1_1CircleGoal.html#a8fd58608bc720b2837cf72455a0e076b", null ],
    [ "draw", "classgoal_1_1CircleGoal.html#a91dfa039728e5b68a97fbfa59f4d03e6", null ],
    [ "colors", "classgoal_1_1CircleGoal.html#a2fcb77d9e22165b8d9bcde9a411d7471", null ],
    [ "position", "classgoal_1_1CircleGoal.html#a5043cf3f8c23c20b038e44888e87622f", null ],
    [ "radius", "classgoal_1_1CircleGoal.html#ab0dbe63cd28b07d45ceedf1bce771b07", null ],
    [ "screen", "classgoal_1_1CircleGoal.html#a0868d7060d53cd1528aa699f65db3df3", null ]
];