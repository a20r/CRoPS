var boid_8py =
[
    [ "Boid", "classboid_1_1Boid.html", "classboid_1_1Boid" ],
    [ "guassianFunc", "boid_8py.html#a9986e7e6ff357ff3f6ea5f526b99f2a7", null ],
    [ "__author__", "boid_8py.html#a45f52f4d0bce17d64ddb37463a344776", null ]
];