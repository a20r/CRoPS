var gatherstats_8py =
[
    [ "generateStats", "gatherstats_8py.html#ad43ef3451dcba9a62629fcdd81fd12fd", null ],
    [ "mapList", "gatherstats_8py.html#ab219c0341d8413916db5431206ab75d9", null ],
    [ "testList", "gatherstats_8py.html#aa220f5cd7b67d3ee630725d3755c1a0c", null ]
];