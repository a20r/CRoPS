var namespaces =
[
    [ "boid", "namespaceboid.html", null ],
    [ "boidsimulation", "namespaceboidsimulation.html", null ],
    [ "configuration", "namespaceconfiguration.html", null ],
    [ "dijkstra", "namespacedijkstra.html", null ],
    [ "gatherstats", "namespacegatherstats.html", null ],
    [ "goal", "namespacegoal.html", null ],
    [ "mapparser", "namespacemapparser.html", null ],
    [ "obstacle", "namespaceobstacle.html", null ],
    [ "priodict", "namespacepriodict.html", null ],
    [ "prm", "namespaceprm.html", null ],
    [ "test_sim", "namespacetest__sim.html", null ]
];