var goal_8py =
[
    [ "CircleGoal", "classgoal_1_1CircleGoal.html", "classgoal_1_1CircleGoal" ],
    [ "__author__", "goal_8py.html#ae04fc72068c7219ebcba5f692ad7457c", null ]
];